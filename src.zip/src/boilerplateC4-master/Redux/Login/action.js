//Action Types:
export const LOGIN = "LOGIN";

//Action Creators:
export const userLogin = (payload) => ({ type: LOGIN, payload });