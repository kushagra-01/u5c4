import "./App.css";
import { Routers } from "./Components/Routers/Routers";

function App() {
  return (
    <div className="App">
      <Routers />
    </div>
  );
}

export default App;
